import 'package:finalmobiles/widgets/table_widget.dart';
import 'package:finalmobiles/widgets/table_list.dart';
import 'package:finalmobiles/widgets/help_note.dart';
import 'package:flutter/material.dart';

class Restaurant extends StatelessWidget {
  const Restaurant({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: TableList(
        builder: (tables) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(
                child: GridView.builder(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                  ),
                  itemCount: tables.length,
                  itemBuilder: (context, index) =>
                      TableWidget(table: tables[index]),
                ),
              ),
              const HelpNote(),
            ],
          );
        },
      ),
    );
  }
}
