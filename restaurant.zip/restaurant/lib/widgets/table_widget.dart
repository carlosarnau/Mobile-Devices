import 'package:finalmobiles/widgets/edit_order.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:finalmobiles/model/model.dart';
import 'package:flutter/material.dart';

class TableWidget extends StatelessWidget {
  const TableWidget({
    Key? key,
    required this.table,
  }) : super(key: key);

  final TableModel table;

  Color _colorFromState(String state) {
    switch (state) {
      case "empty":
        return Colors.green[100]!;
      case "bill":
        return Colors.blue[200]!;
      case "occupied":
        return Colors.red[200]!;
      default:
        return Colors.white;
    }
  }

  static const states = ["empty", "occupied", "bill"];
  String _nextState(String state) {
    final pos = states.indexOf(state);
    return states[(pos + 1) % states.length];
  }

  _changeState() {
    final db = FirebaseFirestore.instance;
    final newState = _nextState(table.state);
    final newData = {
      "state": newState,
      "order": newState == "empty" ? "" : table.order,
    };
    db.doc("/exams/restaurant/tables/${table.id}").set(newData);
  }

  _editOrder(BuildContext context) async {
    if (table.state != "occupied") {
      return;
    }
    final db = FirebaseFirestore.instance;
    final order = await showDialog(
      context: context,
      builder: (context) => EditOrder(
        oldOrder: table.order,
      ),
    );
    if (order != null) {
      db.doc("/exams/restaurant/tables/${table.id}").update({
        "order": order,
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return GridTile(
      header: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Text(
          table.id,
          style: const TextStyle(fontSize: 20),
          textAlign: TextAlign.center,
        ),
      ),
      footer: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Center(
          child: Text(
            table.state,
            style: const TextStyle(fontSize: 18),
          ),
        ),
      ),
      child: Card(
        color: _colorFromState(table.state),
        child: InkWell(
          onLongPress: _changeState,
          onTap: () => _editOrder(context),
          child: Center(
            child: Text(table.order),
          ),
        ),
      ),
    );
  }
}
