import 'package:flutter/material.dart';

class HelpNote extends StatelessWidget {
  const HelpNote({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.grey[400],
      padding: const EdgeInsets.all(12.0),
      child: const Text(
        "Long-press to change table state\n"
        "Click to edit order while table occupied",
        textAlign: TextAlign.center,
        style: TextStyle(
          fontSize: 18,
          color: Colors.white,
        ),
      ),
    );
  }
}
