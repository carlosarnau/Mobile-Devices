import 'package:finalmobiles/model/model.dart';
import 'package:flutter/material.dart';

class TableList extends StatelessWidget {
  final Widget Function(List<TableModel>) builder;
  const TableList({
    super.key,
    required this.builder,
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: dbGetTables(),
      builder: (context, AsyncSnapshot<List<TableModel>> snapshot) {
        if (snapshot.hasError) {
          if (snapshot.error is Error) {
            debugPrint((snapshot.error as Error).stackTrace.toString());
          }
          return ErrorWidget(snapshot.error.toString());
        }
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        final items = snapshot.data!;
        return builder(items);
      },
    );
  }
}
