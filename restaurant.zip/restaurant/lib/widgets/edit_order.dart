import 'package:flutter/material.dart';

class EditOrder extends StatefulWidget {
  final String oldOrder;
  const EditOrder({super.key, required this.oldOrder});

  @override
  State<EditOrder> createState() => _EditOrder();
}

class _EditOrder extends State<EditOrder> {
  final TextEditingController controller = TextEditingController();

  @override
  void initState() {
    controller.text = widget.oldOrder;
    super.initState();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      content: TextField(
        autofocus: true,
        controller: controller,
        minLines: 1,
        maxLines: 6,
      ),
      actions: [
        TextButton(
          child: const Text("Cancel"),
          onPressed: () => Navigator.of(context).pop(),
        ),
        TextButton(
          child: const Text("Save"),
          onPressed: () => Navigator.of(context).pop(controller.text),
        ),
      ],
    );
  }
}
