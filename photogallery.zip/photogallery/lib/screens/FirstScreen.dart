import 'package:finalmobiles/model/model.dart';
import 'package:flutter/material.dart';

class FirstScreen extends StatelessWidget {
  const FirstScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Photo Gallery",
          style: TextStyle(fontSize: 18),
        ),
        backgroundColor: Colors.grey,
      ),
      bottomSheet: Container(
        height: 70,
        color: Colors.grey,
        child: const Center(
          child: Text(
            "Click an image to change it",
            style: TextStyle(fontSize: 18, color: Colors.white),
          ),
        ),
      ),
      body: StreamBuilder(
        stream: dbGetPhotos(),
        builder: ((context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
          List<Photo> currentPhoto = snapshot.data!;
          return GridView.builder(
            primary: false,
            padding: const EdgeInsets.all(20),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 5.0,
              mainAxisSpacing: 25.0,
            ),
            itemCount: currentPhoto.length,
            itemBuilder: (context, index) => ListTile(
              title: Text(
                currentPhoto[index].image,
                textAlign: TextAlign.center,
              ),
              onTap: (() => Navigator.of(context).pushNamed(
                    '/new',
                    arguments: currentPhoto[index].id,
                  )),
              subtitle: Center(
                child: SizedBox(
                  height: 200,
                  width: 200,
                  child: Image.network(currentPhoto[index].link),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}
