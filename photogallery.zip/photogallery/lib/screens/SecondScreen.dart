import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class SecondScreen extends StatefulWidget {
  const SecondScreen({super.key});

  @override
  State<SecondScreen> createState() => _SecondScreen();
}

class _SecondScreen extends State<SecondScreen> {
  final TextEditingController controllerA = TextEditingController();
  final TextEditingController controllerB = TextEditingController();

  String currentImg = 'placeholder';

  String image1 = 'https://picsum.photos/id/26/300/300';

  String image2 = 'https://picsum.photos/id/258/300/300';

  String image3 = 'https://picsum.photos/id/278/300/300';

  String image4 = 'https://picsum.photos/id/23/300/300';

  String image5 = 'https://picsum.photos/id/57/300/300';

  String image6 = 'https://picsum.photos/id/64/300/300';

  String image7 = 'https://picsum.photos/id/99/300/300';

  String image8 = 'https://picsum.photos/id/76/300/300';

  String image9 = 'https://picsum.photos/id/34/300/300';

  String image10 = 'https://picsum.photos/id/71/300/300';

  String image11 = 'https://picsum.photos/id/42/300/300';

  String image12 = 'https://picsum.photos/id/82/300/300';

  String image13 = 'https://picsum.photos/id/113/300/300';

  String image14 = 'https://picsum.photos/id/106/300/300';

  String image15 = 'https://picsum.photos/id/4/300/300';

  String image16 = 'https://picsum.photos/id/12/300/300';

  late int goalAint;
  late int goalBint;

  bool isFinished = false;

  late String id;

  @override
  void dispose() {
    controllerA.dispose();
    controllerB.dispose();
    super.dispose();
  }

  @override
  void didChangeDependencies() {
    final number = ModalRoute.of(context)!.settings.arguments;
    if (number != null) {
      id = "$number";
    } else {
      id = '';
    }

    super.didChangeDependencies();
  }

  void _editImage() {
    if (controllerA.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text("The image's name is missing"),
          backgroundColor: Colors.red[900],
        ),
      );
      return;
    }
    if (currentImg == 'placeholder') {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text("You need to select an Image"),
          backgroundColor: Colors.red[900],
        ),
      );
      return;
    }

    final db = FirebaseFirestore.instance;

    if (id != '') {
      db.doc("/exams/photogallery/photos/$id").set({
        'image': controllerA.text,
        'link': currentImg,
        'createdAt': Timestamp.now(),
      });
    }

    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Edit Photo",
          style: TextStyle(fontSize: 18),
        ),
        backgroundColor: Colors.grey,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            //Image Name
            TextField(
              autofocus: true,
              controller: controllerA,
              decoration: const InputDecoration(
                label: Text("Image Name"),
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Row(
              children: [
                Container(
                  width: 105,
                  height: 105,
                  padding: const EdgeInsets.all(8),
                  child: FloatingActionButton(
                    child: Image.network(image1),
                    onPressed: () => currentImg = image1,
                  ),
                ),
                Container(
                  width: 105,
                  height: 105,
                  padding: const EdgeInsets.all(8),
                  child: FloatingActionButton(
                    child: Image.network(image2),
                    onPressed: () => currentImg = image2,
                  ),
                ),
                Container(
                  width: 105,
                  height: 105,
                  padding: const EdgeInsets.all(8),
                  child: FloatingActionButton(
                    child: Image.network(image3),
                    onPressed: () => currentImg = image3,
                  ),
                ),
                Container(
                  width: 105,
                  height: 105,
                  padding: const EdgeInsets.all(8),
                  child: FloatingActionButton(
                    child: Image.network(image4),
                    onPressed: () => currentImg = image4,
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 5,
            ),
            Row(
              children: [
                Container(
                  width: 105,
                  height: 105,
                  padding: const EdgeInsets.all(8),
                  child: FloatingActionButton(
                    child: Image.network(image5),
                    onPressed: () => currentImg = image5,
                  ),
                ),
                Container(
                  width: 105,
                  height: 105,
                  padding: const EdgeInsets.all(8),
                  child: FloatingActionButton(
                    child: Image.network(image6),
                    onPressed: () => currentImg = image6,
                  ),
                ),
                Container(
                  width: 105,
                  height: 105,
                  padding: const EdgeInsets.all(8),
                  child: FloatingActionButton(
                    child: Image.network(image7),
                    onPressed: () => currentImg = image7,
                  ),
                ),
                Container(
                  width: 105,
                  height: 105,
                  padding: const EdgeInsets.all(8),
                  child: FloatingActionButton(
                    child: Image.network(image8),
                    onPressed: () => currentImg = image8,
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 5,
            ),
            Row(
              children: [
                Container(
                  width: 105,
                  height: 105,
                  padding: const EdgeInsets.all(8),
                  child: FloatingActionButton(
                    child: Image.network(image9),
                    onPressed: () => currentImg = image9,
                  ),
                ),
                Container(
                  width: 105,
                  height: 105,
                  padding: const EdgeInsets.all(8),
                  child: FloatingActionButton(
                    child: Image.network(image10),
                    onPressed: () => currentImg = image10,
                  ),
                ),
                Container(
                  width: 105,
                  height: 105,
                  padding: const EdgeInsets.all(8),
                  child: FloatingActionButton(
                    child: Image.network(image11),
                    onPressed: () => currentImg = image11,
                  ),
                ),
                Container(
                  width: 105,
                  height: 105,
                  padding: const EdgeInsets.all(8),
                  child: FloatingActionButton(
                    child: Image.network(image12),
                    onPressed: () => currentImg = image12,
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 5,
            ),
            Row(
              children: [
                Container(
                  width: 105,
                  height: 105,
                  padding: const EdgeInsets.all(8),
                  child: FloatingActionButton(
                    child: Image.network(image13),
                    onPressed: () => currentImg = image13,
                  ),
                ),
                Container(
                  width: 105,
                  height: 105,
                  padding: const EdgeInsets.all(8),
                  child: FloatingActionButton(
                    child: Image.network(image14),
                    onPressed: () => currentImg = image14,
                  ),
                ),
                Container(
                  width: 105,
                  height: 105,
                  padding: const EdgeInsets.all(8),
                  child: FloatingActionButton(
                    child: Image.network(image15),
                    onPressed: () => currentImg = image15,
                  ),
                ),
                Container(
                  width: 105,
                  height: 105,
                  padding: const EdgeInsets.all(8),
                  child: FloatingActionButton(
                    child: Image.network(image16),
                    onPressed: () => currentImg = image16,
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 20,
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.grey),
              onPressed: _editImage,
              child: const Text("Apply Changes"),
            ),
          ],
        ),
      ),
    );
  }
}
