import 'package:cloud_firestore/cloud_firestore.dart';

class Photo {
  String id;
  String image;
  String link;
  DateTime createdAt;

  Photo.fromFirestrore(DocumentSnapshot<Map<String, dynamic>> docSnap)
      : id = docSnap.id,
        image = docSnap['image'],
        link = docSnap['link'],
        createdAt = (docSnap['createdAt'] as Timestamp).toDate();
}

Stream<List<Photo>> dbGetPhotos() async* {
  final db = FirebaseFirestore.instance;
  final query = db.collection("/exams/photogallery/photos");
  await for (final qsnap in query.snapshots()) {
    List<Photo> photos = [];
    for (final doc in qsnap.docs) {
      photos.add(Photo.fromFirestrore(doc));
    }
    yield photos;
  }
}
