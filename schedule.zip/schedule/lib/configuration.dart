const dbPrefix = "/exams/schedule";
