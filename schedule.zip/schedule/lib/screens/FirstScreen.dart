import 'package:finalmobiles/widgets/screen_text.dart';
import 'package:flutter/material.dart';

class FirstScreen extends StatelessWidget {
  const FirstScreen({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.fromLTRB(32, 48, 32, 48),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Spacer(),
            const ScreenText(
              "Please, choose which time slot you prefer for your flight",
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: () =>
                  Navigator.of(context).pushReplacementNamed('/choose'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.grey,
              ),
              child: const Text("Next"),
            ),
          ],
        ),
      ),
    );
  }
}
