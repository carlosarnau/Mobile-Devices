import 'package:finalmobiles/widgets/screen_text.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:finalmobiles/widgets/time_text.dart';
import 'package:finalmobiles/configuration.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ThirdScreen extends StatelessWidget {
  const ThirdScreen({Key? key}) : super(key: key);

  _save(Map<String, DateTime> selection) async {
    final db = FirebaseFirestore.instance;
    await db.collection("$dbPrefix/users").add({
      'selection': selection.keys.toList(),
      'date': Timestamp.now(),
    });
  }

  @override
  Widget build(BuildContext context) {
    final selected =
        ModalRoute.of(context)!.settings.arguments as Map<String, DateTime>;
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Confirm you Choice",
          style: TextStyle(fontSize: 18),
        ),
        backgroundColor: Colors.grey,
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(32, 48, 32, 48),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const ScreenText("You have chosen:", textAlign: TextAlign.left),
            const SizedBox(height: 8),
            for (final date in selected.values) TimeText(date),
            const Spacer(),
            ElevatedButton(
              onPressed: () => Navigator.of(context).pushReplacementNamed(
                '/choose',
                arguments: selected,
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.grey,
              ),
              child: const Text("Return"),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.grey,
              ),
              onPressed: () async {
                await _save(selected);
                SystemNavigator.pop(); // salir de la app
              },
              child: const Text("Save"),
            ),
          ],
        ),
      ),
    );
  }
}
