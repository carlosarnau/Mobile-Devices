import 'package:finalmobiles/widgets/note_style1.dart';
import 'package:finalmobiles/widgets/match_style.dart';
import 'package:finalmobiles/widgets/matches.dart';
import 'package:flutter/material.dart';

class FirstScreen extends StatelessWidget {
  const FirstScreen({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Journey Results",
          style: TextStyle(fontSize: 18),
        ),
        backgroundColor: Colors.grey,
      ),
      body: MatchesList(builder: (partits) {
        return Column(
          children: [
            const SizedBox(height: 20),
            const Note1("Clik a match to edit it"),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(5.0),
                itemCount: partits.length,
                itemBuilder: (context, index) =>
                    MatchTag(partit: partits[index]),
              ),
            ),
          ],
        );
      }),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.grey,
        child: const Icon(
          Icons.add,
        ),
        onPressed: () => Navigator.of(context).pushNamed('/new'),
      ),
    );
  }
}
