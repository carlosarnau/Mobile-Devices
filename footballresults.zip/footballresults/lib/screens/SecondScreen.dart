import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:finalmobiles/configuration.dart';
import 'package:flutter/material.dart';

class SecondScreen extends StatefulWidget {
  const SecondScreen({super.key});

  @override
  State<SecondScreen> createState() => _SecondScreen();
}

class _SecondScreen extends State<SecondScreen> {
  final TextEditingController controllerA = TextEditingController();
  final TextEditingController controllerB = TextEditingController();

  @override
  void dispose() {
    controllerA.dispose();
    controllerB.dispose();
    super.dispose();
  }

  void _afegeixEquip() {
    if (controllerA.text.isEmpty || controllerB.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Introduce the name of the two teams"),
          backgroundColor: Color.fromARGB(255, 255, 44, 104),
        ),
      );
      return;
    }
    final db = FirebaseFirestore.instance;
    db.collection("$dbPrefix/matches").add({
      'equipA': controllerA.text,
      'equipB': controllerB.text,
      'golsA': 0,
      'golsB': 0,
      'finalitzat': false,
      'started': Timestamp.now(),
    });
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Add match",
          style: TextStyle(fontSize: 18),
        ),
        backgroundColor: Colors.grey,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              autofocus: true,
              controller: controllerA,
              decoration: const InputDecoration(
                label: Text("Team A"),
              ),
            ),
            TextField(
              controller: controllerB,
              decoration: const InputDecoration(
                label: Text("Team B"),
              ),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.grey, // background
                // foreground
              ),
              onPressed: _afegeixEquip,
              child: const Text("Add"),
            ),
          ],
        ),
      ),
    );
  }
}
