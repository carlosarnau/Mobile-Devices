const dbPrefix = "/exams/football";
