import 'package:flutter/material.dart';

class Note1 extends StatelessWidget {
  final String text;
  const Note1(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        color: Colors.black,
        fontStyle: FontStyle.italic,
        fontSize: 10,
      ),
    );
  }
}
