import 'package:finalmobiles/model/model.dart';
import 'package:flutter/material.dart';

class MatchesList extends StatelessWidget {
  final Widget Function(List<Partit>) builder;
  const MatchesList({
    super.key,
    required this.builder,
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
        stream: dbGetPartits(),
        builder: (context, AsyncSnapshot<List<Partit>> snapshot) {
          if (snapshot.hasError) {
            return ErrorWidget(snapshot.error.toString());
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          return builder(snapshot.data!);
        });
  }
}
