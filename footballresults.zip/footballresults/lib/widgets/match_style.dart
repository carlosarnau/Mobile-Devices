import 'package:finalmobiles/widgets/note_style2.dart';
import 'package:finalmobiles/model/model.dart';
import 'package:flutter/material.dart';

class MatchTag extends StatefulWidget {
  final Partit partit;
  const MatchTag({super.key, required this.partit});

  @override
  State<MatchTag> createState() => _MatchByFar();
}

class _MatchByFar extends State<MatchTag> {
  bool editing = false;

  _toggleEditing() {
    if (widget.partit.notFinalitzat) {
      setState(() => editing = !editing);
    }
  }

  _finalitza() async {
    final confirmat = await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Confirmation"),
          content: Text(
            "Are you sure you want to end the match? "
            "'${widget.partit.equipA} - ${widget.partit.equipB}'?",
          ),
          actions: [
            TextButton(
              child: const Text("Cancel"),
              onPressed: () => Navigator.of(context).pop(false),
            ),
            TextButton(
              child: const Text("End"),
              onPressed: () => Navigator.of(context).pop(true),
            ),
          ],
        );
      },
    );
    if (confirmat) {
      setState(() => editing = false);
      widget.partit.finalitza();
    }
  }

  @override
  Widget build(BuildContext context) {
    final finalitzat = widget.partit.finalitzat;
    return Card(
      color: widget.partit.finalitzat
          ? const Color.fromARGB(255, 255, 44, 104)
          : const Color.fromARGB(255, 46, 204, 133),
      child: InkWell(
        onTap: finalitzat ? null : _toggleEditing,
        onLongPress: finalitzat ? null : _finalitza,
        child: Padding(
          padding: const EdgeInsets.symmetric(
            vertical: 12.0,
            horizontal: 18.0,
          ),
          child: Column(
            children: [
              _Result(widget.partit),
              if (editing) ...[
                _Editor(widget.partit),
                const Note2("Long-click to end the match"),
              ]
            ],
          ),
        ),
      ),
    );
  }
}

class _Result extends StatelessWidget {
  final Partit partit;
  const _Result(this.partit);

  @override
  Widget build(BuildContext context) {
    const styleGols = TextStyle(fontSize: 25, color: Colors.white);
    const styleEquips = TextStyle(fontSize: 15, color: Colors.white);
    const space = SizedBox(width: 12);
    return Row(
      children: [
        Text("${partit.golsA}", style: styleGols),
        space,
        Expanded(
          flex: 5,
          child: Text(
            partit.equipA,
            style: styleEquips,
            textAlign: TextAlign.right,
          ),
        ),
        space,
        const SizedBox(
          width: 15,
          child: Divider(
            thickness: 2,
          ),
        ),
        space,
        Expanded(
          flex: 5,
          child: Text(partit.equipB, style: styleEquips),
        ),
        space,
        Text("${partit.golsB}", style: styleGols),
      ],
    );
  }
}

class _Editor extends StatelessWidget {
  final Partit partit;
  const _Editor(this.partit);

  _button(IconData icon, void Function() fn) => OutlinedButton(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(48, 48),
        ),
        onPressed: fn,
        child: Icon(
          icon,
          size: 24,
          color: Colors.white,
        ),
      );

  @override
  Widget build(BuildContext context) {
    const space = SizedBox(width: 5);
    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 12, 0, 12),
      child: Row(
        children: [
          _button(Icons.add, () => partit.incrA(1)),
          space,
          _button(Icons.remove, () => partit.incrA(-1)),
          const Spacer(),
          _button(Icons.remove, () => partit.incrB(-1)),
          space,
          _button(Icons.add, () => partit.incrB(1)),
        ],
      ),
    );
  }
}
