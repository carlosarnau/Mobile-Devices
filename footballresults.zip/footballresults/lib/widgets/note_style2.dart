import 'package:flutter/material.dart';

class Note2 extends StatelessWidget {
  final String text;
  const Note2(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        color: Colors.white,
        fontStyle: FontStyle.italic,
        fontSize: 10,
      ),
    );
  }
}
