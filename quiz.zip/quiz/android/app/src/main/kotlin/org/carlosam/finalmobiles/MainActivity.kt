package org.carlosam.finalmobiles

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
