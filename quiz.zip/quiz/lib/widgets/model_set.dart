import 'package:finalmobiles/model/model.dart';
import 'package:provider/provider.dart';
import 'package:flutter/material.dart';

class ModelSet extends StatefulWidget {
  final Widget child;
  const ModelSet({
    Key? key,
    required this.child,
  }) : super(key: key);

  @override
  State<ModelSet> createState() => _ModelSet();
}

class _ModelSet extends State<ModelSet> {
  @override
  void initState() {
    dbQuizConnect();
    super.initState();
  }

  @override
  void dispose() {
    dbQuizDisconnect();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: dbGetQuiz(),
      builder: (_, AsyncSnapshot<Quiz> snapshot) {
        if (snapshot.hasError) {
          return ErrorWidget(snapshot.error.toString());
        }
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        return Provider<Quiz>.value(
          value: snapshot.data!,
          child: widget.child,
        );
      },
    );
  }
}
