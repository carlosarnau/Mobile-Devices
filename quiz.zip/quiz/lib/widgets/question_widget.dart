import 'package:finalmobiles/model/question.dart';
import 'package:flutter/material.dart';

class QuestionWidget extends StatelessWidget {
  final Pregunta pregunta;
  final int indiceMarcada;

  final void Function(int) onRespuesta;
  const QuestionWidget({
    Key? key,
    required this.pregunta,
    required this.onRespuesta,
    required this.indiceMarcada,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            pregunta.texto,
            textAlign: TextAlign.left,
            style: const TextStyle(fontSize: 20),
          ),
          const SizedBox(height: 30),
          for (int i = 0; i < pregunta.respuestas.length; i++)
            _Answer(
              pregunta.respuestas[i],
              onClick: () => onRespuesta(i),
              marcada: i == indiceMarcada,
            )
        ],
      ),
    );
  }
}

class _Answer extends StatelessWidget {
  final bool marcada;
  final String respuesta;
  final void Function() onClick;
  const _Answer(
    this.respuesta, {
    Key? key,
    required this.onClick,
    this.marcada = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      onPressed: onClick,
      style: OutlinedButton.styleFrom(
        backgroundColor: marcada ? Colors.grey : Colors.white,
        foregroundColor: marcada ? Colors.white : null,
      ),
      child: Row(
        children: [
          Text(
            respuesta,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}
