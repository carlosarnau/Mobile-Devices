import 'package:finalmobiles/widgets/question_widget.dart';
import 'package:finalmobiles/widgets/question_set.dart';
import 'package:finalmobiles/widgets/model_set.dart';
import 'package:finalmobiles/model/question.dart';
import 'package:finalmobiles/model/model.dart';
import 'package:provider/provider.dart';
import 'package:flutter/material.dart';

class FirstScreen extends StatelessWidget {
  const FirstScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ModelSet(
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            "Super Quiz",
            style: TextStyle(fontSize: 18),
          ),
          backgroundColor: Colors.grey,
          actions: const [
            _Connected(),
          ],
        ),
        body: const QuestionSet(
          child: _Body(),
        ),
      ),
    );
  }
}

class _Body extends StatefulWidget {
  const _Body({Key? key}) : super(key: key);

  @override
  State<_Body> createState() => _BodyState();
}

class _BodyState extends State<_Body> {
  int indiceActual = 0;
  int respuesta = -1;
  int totalCorrectas = 0;

  _siguiente() {
    final preguntas = context.read<List<Pregunta>>();
    final preguntaActual = preguntas[indiceActual];
    if (respuesta == preguntaActual.correcta) {
      totalCorrectas++;
    }
    if (indiceActual + 1 >= preguntas.length) {
      Navigator.of(context).pushReplacementNamed('/results', arguments: {
        'correctas': totalCorrectas,
        'total': preguntas.length,
      });
    } else {
      indiceActual++;
      respuesta = -1;
    }
  }

  @override
  Widget build(BuildContext context) {
    final preguntas = context.read<List<Pregunta>>();
    return Padding(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _Title(indiceActual + 1),
          QuestionWidget(
            pregunta: preguntas[indiceActual],
            onRespuesta: (int i) {
              setState(() => respuesta = i);
            },
            indiceMarcada: respuesta,
          ),
          const Spacer(),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              ElevatedButton(
                onPressed: respuesta != -1 ? () => setState(_siguiente) : null,
                child: Row(
                  children: const [
                    Text("Next"),
                    SizedBox(width: 6),
                    Icon(Icons.arrow_forward),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Title extends StatelessWidget {
  const _Title(
    this.indicePregunta, {
    Key? key,
  }) : super(key: key);

  final int indicePregunta;

  @override
  Widget build(BuildContext context) {
    return Text(
      "Question $indicePregunta",
      style: const TextStyle(
        fontSize: 15,
        fontWeight: FontWeight.w300,
        color: Colors.grey,
      ),
    );
  }
}

class _Connected extends StatelessWidget {
  const _Connected({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final quiz = context.watch<Quiz>();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Row(
        children: [
          const Icon(Icons.group),
          const SizedBox(width: 10),
          Text(quiz.conectados.toString()),
        ],
      ),
    );
  }
}
