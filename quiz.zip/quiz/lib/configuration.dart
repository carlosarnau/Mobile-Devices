const dbPrefix = '/exams/quiz';
